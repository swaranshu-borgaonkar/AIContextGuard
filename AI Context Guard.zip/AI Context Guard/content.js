// AI Context Guard - Content Script v1.2.1
// Comprehensive sensitive data detection for AI platforms

(function() {
  'use strict';

  // Prevent double initialization
  if (window.__ACG_INITIALIZED__) return;
  window.__ACG_INITIALIZED__ = true;

  // ===========================================
  // CONFIGURATION
  // ===========================================
  
  const CONFIG = {
    enableWarnings: true,
    enableAutoRedact: true,
    enableLogging: true,
    scanDelay: 300
  };

  let currentConfig = { ...CONFIG };
  let scanTimeout = null;
  let activeWarning = null;
  let lastScannedText = '';

  // ===========================================
  // DETECTION PATTERNS (FIXED)
  // ===========================================
  
  const PATTERNS = [
    // AWS Keys
    {
      name: 'AWS Access Key',
      pattern: /\b(AKIA[0-9A-Z]{16})\b/g,
      severity: 'critical'
    },
    {
      name: 'AWS Secret Key',
      pattern: /(?:aws_secret_access_key|aws_secret|secret_key)["'\s:=]+([A-Za-z0-9/+=]{40})/gi,
      severity: 'critical'
    },
    
    // OpenAI API Keys (FIXED patterns)
    {
      name: 'OpenAI API Key',
      pattern: /\b(sk-[A-Za-z0-9]{32,})\b/g,
      severity: 'critical',
      validate: (match) => match.startsWith('sk-') && match.length >= 40 && !match.startsWith('sk-ant')
    },
    {
      name: 'OpenAI Project Key',
      pattern: /\b(sk-proj-[A-Za-z0-9_-]{40,})\b/g,
      severity: 'critical'
    },
    
    // Anthropic API Key (FIXED - flexible length)
    {
      name: 'Anthropic API Key',
      pattern: /\b(sk-ant-[A-Za-z0-9_-]{80,})\b/g,
      severity: 'critical'
    },
    
    // Google API Key
    {
      name: 'Google API Key',
      pattern: /\b(AIza[0-9A-Za-z_-]{35})\b/g,
      severity: 'critical'
    },
    
    // GitHub Tokens
    {
      name: 'GitHub Token',
      pattern: /\b(ghp_[A-Za-z0-9]{36}|gho_[A-Za-z0-9]{36}|ghu_[A-Za-z0-9]{36}|ghs_[A-Za-z0-9]{36}|ghr_[A-Za-z0-9]{36})\b/g,
      severity: 'critical'
    },
    {
      name: 'GitHub PAT',
      pattern: /\b(github_pat_[A-Za-z0-9]{22}_[A-Za-z0-9]{59})\b/g,
      severity: 'critical'
    },
    
    // GitLab Token
    {
      name: 'GitLab Token',
      pattern: /\b(glpat-[A-Za-z0-9_-]{20,})\b/g,
      severity: 'critical'
    },
    
    // Slack Tokens
    {
      name: 'Slack Token',
      pattern: /\b(xox[baprs]-[0-9A-Za-z-]{10,})\b/g,
      severity: 'critical'
    },
    {
      name: 'Slack Webhook',
      pattern: /https:\/\/hooks\.slack\.com\/services\/T[A-Z0-9]+\/B[A-Z0-9]+\/[A-Za-z0-9]+/g,
      severity: 'critical'
    },
    
    // Stripe Keys
    {
      name: 'Stripe Live Key',
      pattern: /\b(sk_live_[A-Za-z0-9]{24,}|rk_live_[A-Za-z0-9]{24,})\b/g,
      severity: 'critical'
    },
    {
      name: 'Stripe Test Key',
      pattern: /\b(sk_test_[A-Za-z0-9]{24,}|rk_test_[A-Za-z0-9]{24,})\b/g,
      severity: 'high'
    },
    
    // Twilio
    {
      name: 'Twilio API Key',
      pattern: /\b(SK[a-f0-9]{32})\b/g,
      severity: 'critical'
    },
    {
      name: 'Twilio Account SID',
      pattern: /\b(AC[a-f0-9]{32})\b/g,
      severity: 'high'
    },
    
    // SendGrid
    {
      name: 'SendGrid API Key',
      pattern: /\b(SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43})\b/g,
      severity: 'critical'
    },
    
    // Mailgun
    {
      name: 'Mailgun API Key',
      pattern: /\b(key-[a-f0-9]{32})\b/g,
      severity: 'critical'
    },
    
    // Discord
    {
      name: 'Discord Bot Token',
      pattern: /\b([MN][A-Za-z0-9]{23,}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{27,})\b/g,
      severity: 'critical'
    },
    {
      name: 'Discord Webhook',
      pattern: /https:\/\/discord(?:app)?\.com\/api\/webhooks\/[0-9]+\/[A-Za-z0-9_-]+/g,
      severity: 'critical'
    },
    
    // NPM & PyPI
    {
      name: 'NPM Token',
      pattern: /\b(npm_[A-Za-z0-9]{36})\b/g,
      severity: 'critical'
    },
    {
      name: 'PyPI Token',
      pattern: /\b(pypi-[A-Za-z0-9_-]{50,})\b/g,
      severity: 'critical'
    },
    
    // Private Keys
    {
      name: 'RSA Private Key',
      pattern: /-----BEGIN RSA PRIVATE KEY-----[\s\S]*?-----END RSA PRIVATE KEY-----/g,
      severity: 'critical'
    },
    {
      name: 'OpenSSH Private Key',
      pattern: /-----BEGIN OPENSSH PRIVATE KEY-----[\s\S]*?-----END OPENSSH PRIVATE KEY-----/g,
      severity: 'critical'
    },
    {
      name: 'PGP Private Key',
      pattern: /-----BEGIN PGP PRIVATE KEY BLOCK-----[\s\S]*?-----END PGP PRIVATE KEY BLOCK-----/g,
      severity: 'critical'
    },
    {
      name: 'EC Private Key',
      pattern: /-----BEGIN EC PRIVATE KEY-----[\s\S]*?-----END EC PRIVATE KEY-----/g,
      severity: 'critical'
    },
    {
      name: 'Generic Private Key',
      pattern: /-----BEGIN PRIVATE KEY-----[\s\S]*?-----END PRIVATE KEY-----/g,
      severity: 'critical'
    },
    
    // JWT Token (FIXED validation)
    {
      name: 'JWT Token',
      pattern: /\b(eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})\b/g,
      severity: 'high',
      validate: (match) => {
        const parts = match.split('.');
        if (parts.length !== 3) return false;
        try {
          // Handle URL-safe base64
          const header = parts[0].replace(/-/g, '+').replace(/_/g, '/');
          const padded = header + '='.repeat((4 - header.length % 4) % 4);
          const decoded = atob(padded);
          const parsed = JSON.parse(decoded);
          return parsed.alg !== undefined || parsed.typ !== undefined;
        } catch { 
          return true; // Still flag it even if we can't validate structure
        }
      }
    },
    
    // Bearer Token
    {
      name: 'Bearer Token',
      pattern: /\bBearer\s+([A-Za-z0-9_-]{20,})/gi,
      severity: 'high'
    },
    
    // Basic Auth
    {
      name: 'Basic Auth Header',
      pattern: /\bBasic\s+([A-Za-z0-9+/]{20,}=*)/gi,
      severity: 'high'
    },
    
    // Database Connection Strings
    {
      name: 'MongoDB Connection',
      pattern: /mongodb(?:\+srv)?:\/\/[^\s"'<>]{10,}/gi,
      severity: 'critical'
    },
    {
      name: 'PostgreSQL Connection',
      pattern: /postgres(?:ql)?:\/\/[^\s"'<>]{10,}/gi,
      severity: 'critical'
    },
    {
      name: 'MySQL Connection',
      pattern: /mysql:\/\/[^\s"'<>]{10,}/gi,
      severity: 'critical'
    },
    {
      name: 'Redis Connection',
      pattern: /redis:\/\/[^\s"'<>]{10,}/gi,
      severity: 'critical'
    },
    
    // Credit Card (with Luhn validation)
    {
      name: 'Credit Card Number',
      pattern: /\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\b/g,
      severity: 'critical',
      validate: (match) => luhnCheck(match)
    },
    
    // IBAN (FIXED - handles spaces)
    {
      name: 'IBAN',
      pattern: /\b[A-Z]{2}\s?[0-9]{2}\s?(?:[A-Z0-9]\s?){11,30}\b/g,
      severity: 'critical',
      validate: (match) => {
        const cleaned = match.replace(/\s/g, '');
        return cleaned.length >= 15 && cleaned.length <= 34;
      }
    },
    
    // SSN (US)
    {
      name: 'Social Security Number',
      pattern: /\b(?!000|666|9\d{2})([0-9]{3})[-\s]?(?!00)([0-9]{2})[-\s]?(?!0000)([0-9]{4})\b/g,
      severity: 'critical',
      validate: (match) => {
        const cleaned = match.replace(/[-\s]/g, '');
        return cleaned.length === 9 && !/^(\d)\1{8}$/.test(cleaned);
      }
    },
    
    // Private IP Addresses
    {
      name: 'Private IPv4 Address',
      pattern: /\b(?:10\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}|172\.(?:1[6-9]|2[0-9]|3[01])\.[0-9]{1,3}\.[0-9]{1,3}|192\.168\.[0-9]{1,3}\.[0-9]{1,3})\b/g,
      severity: 'high'
    },
    
    // Internal URLs
    {
      name: 'Internal URL',
      pattern: /https?:\/\/(?:localhost|127\.0\.0\.1|10\.[0-9.]+|172\.(?:1[6-9]|2[0-9]|3[01])\.[0-9.]+|192\.168\.[0-9.]+|[a-z0-9-]+\.(?:internal|local|corp|lan|priv))[^\s"'<>]*/gi,
      severity: 'high'
    },
    
    // AWS ARN
    {
      name: 'AWS ARN',
      pattern: /arn:aws:[a-z0-9-]+:[a-z0-9-]*:[0-9]*:[a-zA-Z0-9-_/:.]+/g,
      severity: 'high'
    },
    
    // Azure
    {
      name: 'Azure Connection String',
      pattern: /DefaultEndpointsProtocol=https?;AccountName=[^;]+;AccountKey=[^;]+/g,
      severity: 'critical'
    },
    
    // Password Assignments
    {
      name: 'Password Assignment',
      pattern: /(?:password|passwd|pwd|secret)["'\s]*[:=]["'\s]*([^\s"']{8,})/gi,
      severity: 'critical'
    },
    
    // Environment Variables with Secrets
    {
      name: 'Secret Environment Variable',
      pattern: /\b(?:export\s+)?(?:[A-Z_]*(?:SECRET|PASSWORD|TOKEN|KEY|API|AUTH|CREDENTIAL)[A-Z_]*)=["']?[^\s"']+["']?/gi,
      severity: 'high'
    },
    
    // Generic API Key Assignment
    {
      name: 'API Key Assignment',
      pattern: /(?:api[_-]?key|apikey)["'\s]*[:=]["'\s]*([A-Za-z0-9_-]{20,})/gi,
      severity: 'high'
    },
    
    // Work Email (more specific than all emails)
    {
      name: 'Corporate Email',
      pattern: /\b[A-Za-z0-9._%+-]+@(?!gmail|yahoo|hotmail|outlook|icloud|proton)[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g,
      severity: 'medium',
      validate: (match) => {
        // Exclude obvious test/example emails
        const lower = match.toLowerCase();
        return !lower.includes('example') && !lower.includes('test') && !lower.includes('@localhost');
      }
    },
    
    // Phone Numbers (US format, more specific)
    {
      name: 'US Phone Number',
      pattern: /\b(?:\+1[-.\s]?)?(?:\([2-9][0-9]{2}\)|[2-9][0-9]{2})[-.\s]?[2-9][0-9]{2}[-.\s]?[0-9]{4}\b/g,
      severity: 'medium',
      context: /phone|mobile|cell|contact|tel/i
    }
  ];

  // ===========================================
  // HELPER FUNCTIONS
  // ===========================================

  // Luhn algorithm for credit card validation
  function luhnCheck(cardNumber) {
    const digits = cardNumber.replace(/\D/g, '');
    if (digits.length < 13 || digits.length > 19) return false;
    
    let sum = 0;
    let isEven = false;
    
    for (let i = digits.length - 1; i >= 0; i--) {
      let digit = parseInt(digits[i], 10);
      if (isEven) {
        digit *= 2;
        if (digit > 9) digit -= 9;
      }
      sum += digit;
      isEven = !isEven;
    }
    
    return sum % 10 === 0;
  }

  function maskValue(value) {
    if (value.length <= 8) return '*'.repeat(value.length);
    return value.slice(0, 4) + '*'.repeat(Math.min(value.length - 8, 20)) + value.slice(-4);
  }

  // ===========================================
  // DETECTION ENGINE
  // ===========================================
  
  function scanText(text) {
    if (!text || typeof text !== 'string' || text.length < 10) return [];
    
    // Avoid rescanning identical text
    if (text === lastScannedText) return [];
    
    const findings = [];
    const seen = new Set();
    
    for (const pattern of PATTERNS) {
      // Reset regex state for global patterns
      pattern.pattern.lastIndex = 0;
      let match;
      
      while ((match = pattern.pattern.exec(text)) !== null) {
        const value = match[1] || match[0];
        const key = `${pattern.name}:${value.slice(0, 20)}`;
        
        if (seen.has(key)) continue;
        
        // Context check - only apply if pattern requires context
        if (pattern.context) {
          const contextStart = Math.max(0, match.index - 100);
          const contextEnd = Math.min(text.length, match.index + value.length + 100);
          const context = text.slice(contextStart, contextEnd);
          if (!pattern.context.test(context)) continue;
        }
        
        // Validation check
        if (pattern.validate && !pattern.validate(value)) continue;
        
        seen.add(key);
        findings.push({
          type: pattern.name,
          severity: pattern.severity,
          value: value,
          masked: maskValue(value),
          index: match.index,
          length: value.length
        });
      }
    }
    
    // Sort by severity
    const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    findings.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);
    
    lastScannedText = text;
    return findings;
  }

  function redactText(text, findings) {
    if (!findings.length) return text;
    
    // Sort by index descending to replace from end
    const sorted = [...findings].sort((a, b) => b.index - a.index);
    let result = text;
    
    for (const finding of sorted) {
      const replacement = `[REDACTED:${finding.type}]`;
      result = result.slice(0, finding.index) + replacement + result.slice(finding.index + finding.length);
    }
    
    return result;
  }

  // ===========================================
  // INPUT HANDLING
  // ===========================================

  function getInputValue(element) {
    if (!element) return '';
    if (element.isContentEditable || element.getAttribute('contenteditable') === 'true') {
      return element.innerText || element.textContent || '';
    }
    return element.value || '';
  }

  function setInputValue(element, value) {
    if (!element) return;
    
    if (element.isContentEditable || element.getAttribute('contenteditable') === 'true') {
      element.innerText = value;
    } else {
      element.value = value;
    }
    
    // Trigger events for React/Vue/Angular
    element.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    element.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
  }

  function insertTextAtCursor(element, text) {
    if (!element) return false;
    
    if (element.isContentEditable || element.getAttribute('contenteditable') === 'true') {
      // Modern approach for contenteditable
      const selection = window.getSelection();
      if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        range.deleteContents();
        const textNode = document.createTextNode(text);
        range.insertNode(textNode);
        range.setStartAfter(textNode);
        range.setEndAfter(textNode);
        selection.removeAllRanges();
        selection.addRange(range);
      } else {
        element.innerText += text;
      }
    } else {
      // For input/textarea
      const start = element.selectionStart || 0;
      const end = element.selectionEnd || 0;
      const current = element.value || '';
      element.value = current.slice(0, start) + text + current.slice(end);
      element.selectionStart = element.selectionEnd = start + text.length;
    }
    
    // Trigger input event
    element.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    return true;
  }

  function isInputElement(element) {
    if (!element) return false;
    const tag = element.tagName?.toLowerCase();
    return tag === 'input' || 
           tag === 'textarea' || 
           element.isContentEditable || 
           element.getAttribute('contenteditable') === 'true' ||
           element.getAttribute('role') === 'textbox';
  }

  // ===========================================
  // WARNING MODAL
  // ===========================================
  
  function createWarningModal(findings, onAction) {
    removeWarning();
    
    const criticalCount = findings.filter(f => f.severity === 'critical').length;
    const highCount = findings.filter(f => f.severity === 'high').length;
    const mediumCount = findings.filter(f => f.severity === 'medium').length;
    const maxSeverity = criticalCount > 0 ? 'critical' : (highCount > 0 ? 'high' : 'medium');
    
    const overlay = document.createElement('div');
    overlay.id = 'acg-warning-overlay';
    overlay.className = `acg-severity-${maxSeverity}`;
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-labelledby', 'acg-warning-title');
    
    const displayFindings = findings.slice(0, 8);
    const moreCount = findings.length - displayFindings.length;
    
    overlay.innerHTML = `
      <div class="acg-warning-modal">
        <div class="acg-warning-header acg-${maxSeverity}">
          <span class="acg-warning-icon">⚠️</span>
          <h2 class="acg-warning-title" id="acg-warning-title">Sensitive Data Detected</h2>
          <button class="acg-close-btn" aria-label="Close" tabindex="0">×</button>
        </div>
        <div class="acg-warning-body">
          <p class="acg-warning-message">
            <strong>${findings.length} sensitive item${findings.length > 1 ? 's' : ''}</strong> detected in your message. 
            This data could be exposed to the AI platform.
          </p>
          <div class="acg-severity-summary">
            ${criticalCount > 0 ? `<span class="acg-severity-badge acg-critical">${criticalCount} Critical</span>` : ''}
            ${highCount > 0 ? `<span class="acg-severity-badge acg-high">${highCount} High</span>` : ''}
            ${mediumCount > 0 ? `<span class="acg-severity-badge acg-medium">${mediumCount} Medium</span>` : ''}
          </div>
          <div class="acg-findings-list">
            ${displayFindings.map(f => `
              <span class="acg-finding-tag acg-severity-${f.severity}" title="${f.masked}">
                ${f.type}
              </span>
            `).join('')}
            ${moreCount > 0 ? `<span class="acg-finding-more">+${moreCount} more</span>` : ''}
          </div>
        </div>
        <div class="acg-warning-actions">
          ${currentConfig.enableAutoRedact ? `
            <button class="acg-btn acg-btn-redact" tabindex="0">
              <span>🛡️</span> Redact & Send
            </button>
          ` : ''}
          <button class="acg-btn acg-btn-cancel" tabindex="0">
            <span>✋</span> Cancel
          </button>
          <button class="acg-btn acg-btn-force" tabindex="0">
            <span>⚡</span> Send Anyway
          </button>
        </div>
        <div class="acg-warning-footer">
          AI Context Guard • Protecting your sensitive data
        </div>
      </div>
    `;
    
    // Prevent body scroll
    document.body.style.overflow = 'hidden';
    
    // Get action buttons
    const modal = overlay.querySelector('.acg-warning-modal');
    const closeBtn = overlay.querySelector('.acg-close-btn');
    const redactBtn = overlay.querySelector('.acg-btn-redact');
    const cancelBtn = overlay.querySelector('.acg-btn-cancel');
    const forceBtn = overlay.querySelector('.acg-btn-force');
    
    // Focusable elements for focus trap
    const focusableElements = overlay.querySelectorAll('button');
    const firstFocusable = focusableElements[0];
    const lastFocusable = focusableElements[focusableElements.length - 1];
    
    // Event handlers
    const handleAction = (action) => {
      onAction(action);
      removeWarning();
    };
    
    closeBtn?.addEventListener('click', () => handleAction('cancelled'));
    redactBtn?.addEventListener('click', () => handleAction('redacted'));
    cancelBtn?.addEventListener('click', () => handleAction('cancelled'));
    forceBtn?.addEventListener('click', () => handleAction('forced'));
    
    // Keyboard handling with focus trap
    const keyHandler = (e) => {
      if (e.key === 'Escape') {
        handleAction('cancelled');
        return;
      }
      
      // Focus trap
      if (e.key === 'Tab') {
        if (e.shiftKey && document.activeElement === firstFocusable) {
          e.preventDefault();
          lastFocusable.focus();
        } else if (!e.shiftKey && document.activeElement === lastFocusable) {
          e.preventDefault();
          firstFocusable.focus();
        }
      }
    };
    
    document.addEventListener('keydown', keyHandler);
    overlay.__keyHandler = keyHandler;
    
    // Close on backdrop click
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        handleAction('cancelled');
      }
    });
    
    // Prevent clicks inside modal from bubbling
    modal.addEventListener('click', (e) => e.stopPropagation());
    
    document.body.appendChild(overlay);
    activeWarning = overlay;
    
    // Focus first button
    (redactBtn || cancelBtn)?.focus();
  }

  function removeWarning() {
    if (activeWarning) {
      if (activeWarning.__keyHandler) {
        document.removeEventListener('keydown', activeWarning.__keyHandler);
      }
      activeWarning.remove();
      activeWarning = null;
      document.body.style.overflow = '';
    }
  }

  // ===========================================
  // EVENT HANDLERS (DEFINED BEFORE USE)
  // ===========================================

  function handlePaste(event) {
    if (!currentConfig.enableWarnings) return;
    
    const clipboardData = event.clipboardData || window.clipboardData;
    if (!clipboardData) return;
    
    const text = clipboardData.getData('text/plain') || clipboardData.getData('text');
    if (!text || text.length < 10) return;
    
    const findings = scanText(text);
    if (findings.length === 0) return;
    
    // Prevent paste
    event.preventDefault();
    event.stopPropagation();
    
    const element = event.target;
    
    createWarningModal(findings, async (action) => {
      if (action === 'redacted') {
        const redacted = redactText(text, findings);
        insertTextAtCursor(element, redacted);
      } else if (action === 'forced') {
        insertTextAtCursor(element, text);
      }
      // If cancelled, do nothing (text not pasted)
      
      await logEvent({
        action: action,
        findingsCount: findings.length,
        critical: findings.filter(f => f.severity === 'critical').length,
        high: findings.filter(f => f.severity === 'high').length,
        medium: findings.filter(f => f.severity === 'medium').length,
        types: [...new Set(findings.map(f => f.type))]
      });
    });
  }

  function handleKeydown(event) {
    if (!currentConfig.enableWarnings) return;
    
    // Only intercept Enter (submit) on AI chat inputs
    if (event.key !== 'Enter' || event.shiftKey) return;
    
    const element = event.target;
    if (!isInputElement(element)) return;
    
    // Skip if element is in a form (form will handle submit)
    if (element.form) return;
    
    // Debounce - don't scan if we just scanned
    const text = getInputValue(element);
    if (!text || text.length < 10) return;
    
    // Reset lastScannedText to force rescan on Enter
    lastScannedText = '';
    const findings = scanText(text);
    if (findings.length === 0) return;
    
    event.preventDefault();
    event.stopPropagation();
    
    createWarningModal(findings, async (action) => {
      if (action === 'redacted') {
        setInputValue(element, redactText(text, findings));
      }
      
      // Re-trigger Enter after action
      if (action === 'redacted' || action === 'forced') {
        // Small delay to ensure value is set
        setTimeout(() => {
          const enterEvent = new KeyboardEvent('keydown', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true,
            cancelable: true
          });
          element.dispatchEvent(enterEvent);
        }, 50);
      }
      
      await logEvent({
        action: action,
        findingsCount: findings.length,
        critical: findings.filter(f => f.severity === 'critical').length,
        high: findings.filter(f => f.severity === 'high').length,
        medium: findings.filter(f => f.severity === 'medium').length,
        types: [...new Set(findings.map(f => f.type))]
      });
    });
  }

  // Debounced input scanning for real-time feedback
  function handleInput(event) {
    if (!currentConfig.enableWarnings) return;
    
    const element = event.target;
    if (!isInputElement(element)) return;
    
    // Clear existing timeout
    if (scanTimeout) {
      clearTimeout(scanTimeout);
    }
    
    // Debounce scanning
    scanTimeout = setTimeout(() => {
      const text = getInputValue(element);
      // Pre-scan to warm cache
      lastScannedText = ''; // Reset to allow scan
      scanText(text);
    }, currentConfig.scanDelay);
  }

  // ===========================================
  // EVENT LOGGING
  // ===========================================
  
  async function logEvent(eventData) {
    if (!currentConfig.enableLogging) return;
    
    try {
      const result = await chrome.storage.local.get('acgEvents');
      const events = result.acgEvents || [];
      
      events.push({
        ...eventData,
        timestamp: new Date().toISOString(),
        url: window.location.hostname
      });
      
      // Keep only last 1000 events
      if (events.length > 1000) {
        events.splice(0, events.length - 1000);
      }
      
      await chrome.storage.local.set({ acgEvents: events });
    } catch (e) {
      console.debug('[ACG] Could not log event:', e);
    }
  }

  // ===========================================
  // CONFIGURATION
  // ===========================================

  async function loadConfig() {
    try {
      const result = await chrome.storage.local.get('acgConfig');
      if (result.acgConfig) {
        currentConfig = { ...CONFIG, ...result.acgConfig };
      }
    } catch (e) {
      console.debug('[ACG] Could not load config:', e);
    }
  }

  // Listen for config changes
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.acgConfig) {
      currentConfig = { ...CONFIG, ...changes.acgConfig.newValue };
      console.debug('[ACG] Config updated');
    }
  });

  // ===========================================
  // INITIALIZATION
  // ===========================================
  
  function attachListeners() {
    // Use capture phase to intercept before the site
    document.addEventListener('paste', handlePaste, true);
    document.addEventListener('keydown', handleKeydown, true);
    document.addEventListener('input', handleInput, true);
    
    console.debug('[ACG] Event listeners attached');
  }

  // Watch for dynamically added inputs
  function setupMutationObserver() {
    const observer = new MutationObserver((mutations) => {
      // Using event delegation, no need to attach per-element
      // This observer is kept for potential future use
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  async function init() {
    await loadConfig();
    attachListeners();
    setupMutationObserver();
    console.log('[AI Context Guard] Active on', window.location.hostname);
  }

  // Start
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
