// AI Context Guard - Options Script v1.2.0

class OptionsManager {
  constructor() {
    this.config = {
      enableWarnings: true,
      enableAutoRedact: true,
      enableLogging: true,
      scanDelay: 300
    };

    this.detectionTypes = [
      { name: 'AWS Access Key', severity: 'critical' },
      { name: 'AWS Secret Key', severity: 'critical' },
      { name: 'OpenAI API Key', severity: 'critical' },
      { name: 'Anthropic API Key', severity: 'critical' },
      { name: 'Google API Key', severity: 'critical' },
      { name: 'GitHub Token', severity: 'critical' },
      { name: 'GitLab Token', severity: 'critical' },
      { name: 'Slack Token', severity: 'critical' },
      { name: 'Stripe Key', severity: 'critical' },
      { name: 'Discord Token', severity: 'critical' },
      { name: 'SendGrid API Key', severity: 'critical' },
      { name: 'Twilio API Key', severity: 'critical' },
      { name: 'NPM Token', severity: 'critical' },
      { name: 'PyPI Token', severity: 'critical' },
      { name: 'RSA Private Key', severity: 'critical' },
      { name: 'SSH Private Key', severity: 'critical' },
      { name: 'Database Connection', severity: 'critical' },
      { name: 'Social Security Number', severity: 'critical' },
      { name: 'Credit Card Number', severity: 'critical' },
      { name: 'IBAN', severity: 'critical' },
      { name: 'Password Assignment', severity: 'critical' },
      { name: 'JWT Token', severity: 'high' },
      { name: 'Bearer Token', severity: 'high' },
      { name: 'API Keys (Generic)', severity: 'high' },
      { name: 'Environment Variables', severity: 'high' },
      { name: 'Private IP Address', severity: 'high' },
      { name: 'Internal URLs', severity: 'high' },
      { name: 'AWS ARN', severity: 'high' },
      { name: 'Azure Connection', severity: 'high' },
      { name: 'Passport Number', severity: 'high' },
      { name: 'Medical Record ID', severity: 'high' },
      { name: 'Email Address', severity: 'medium' },
      { name: 'Phone Number', severity: 'medium' },
      { name: 'Hex Encoded Secret', severity: 'medium' }
    ];

    this.init();
  }

  async init() {
    await this.loadSettings();
    await this.loadStats();
    this.renderDetectionTypes();
    this.setupEventListeners();
    this.setupStorageListener();
  }

  setupStorageListener() {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      
      if (changes.acgConfig) {
        this.config = { ...this.config, ...changes.acgConfig.newValue };
        this.updateUI();
      }
      
      if (changes.acgEvents) {
        this.updateStatsFromEvents(changes.acgEvents.newValue || []);
      }
    });
  }

  async loadSettings() {
    try {
      const result = await chrome.storage.local.get('acgConfig');
      if (result.acgConfig) {
        this.config = { ...this.config, ...result.acgConfig };
      }
      this.updateUI();
    } catch (error) {
      console.error('[AI Context Guard Options] Error loading settings:', error);
    }
  }

  async loadStats() {
    try {
      const result = await chrome.storage.local.get('acgEvents');
      this.updateStatsFromEvents(result.acgEvents || []);
    } catch (error) {
      console.error('[AI Context Guard Options] Error loading stats:', error);
    }
  }

  updateStatsFromEvents(events) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayEvents = events.filter(event => {
      const eventDate = new Date(event.timestamp);
      eventDate.setHours(0, 0, 0, 0);
      return eventDate.getTime() === today.getTime();
    });

    document.getElementById('statTodayEvents').textContent = todayEvents.length;
    document.getElementById('statCritical').textContent = todayEvents.reduce((sum, e) => sum + (e.critical || 0), 0);
    document.getElementById('statRedacted').textContent = todayEvents.filter(e => e.action === 'redacted').length;
    document.getElementById('statTotal').textContent = events.length;
  }

  updateUI() {
    this.setToggleState('toggleWarnings', this.config.enableWarnings);
    this.setToggleState('toggleAutoRedact', this.config.enableAutoRedact);
    this.setToggleState('toggleLogging', this.config.enableLogging);

    const slider = document.getElementById('scanDelay');
    const sliderValue = document.getElementById('scanDelayValue');
    slider.value = this.config.scanDelay;
    sliderValue.textContent = `${this.config.scanDelay}ms`;
  }

  setToggleState(id, enabled) {
    const toggle = document.getElementById(id);
    if (enabled) {
      toggle.classList.add('enabled');
    } else {
      toggle.classList.remove('enabled');
    }
  }

  renderDetectionTypes() {
    const grid = document.getElementById('detectionGrid');
    grid.innerHTML = this.detectionTypes.map(type => `
      <div class="detection-item">
        <div class="detection-name">${type.name}</div>
        <span class="detection-severity ${type.severity}">${type.severity.toUpperCase()}</span>
      </div>
    `).join('');
  }

  setupEventListeners() {
    // Toggle handlers
    document.getElementById('toggleWarnings').addEventListener('click', (e) => {
      const enabled = !e.target.classList.contains('enabled');
      this.setToggleState('toggleWarnings', enabled);
      this.saveConfig({ enableWarnings: enabled });
    });

    document.getElementById('toggleAutoRedact').addEventListener('click', (e) => {
      const enabled = !e.target.classList.contains('enabled');
      this.setToggleState('toggleAutoRedact', enabled);
      this.saveConfig({ enableAutoRedact: enabled });
    });

    document.getElementById('toggleLogging').addEventListener('click', (e) => {
      const enabled = !e.target.classList.contains('enabled');
      this.setToggleState('toggleLogging', enabled);
      this.saveConfig({ enableLogging: enabled });
    });

    // Slider handler
    const slider = document.getElementById('scanDelay');
    const sliderValue = document.getElementById('scanDelayValue');
    slider.addEventListener('input', (e) => {
      const value = parseInt(e.target.value);
      sliderValue.textContent = `${value}ms`;
      this.saveConfig({ scanDelay: value });
    });

    // Danger zone buttons
    document.getElementById('clearHistoryBtn').addEventListener('click', async () => {
      if (confirm('Are you sure you want to clear all history? This cannot be undone.')) {
        await chrome.storage.local.set({ acgEvents: [] });
        this.loadStats();
        alert('History cleared successfully.');
      }
    });

    document.getElementById('resetSettingsBtn').addEventListener('click', async () => {
      if (confirm('Reset all settings to defaults?')) {
        const defaults = {
          enableWarnings: true,
          enableAutoRedact: true,
          enableLogging: true,
          scanDelay: 300
        };
        await chrome.storage.local.set({ acgConfig: defaults });
        this.config = defaults;
        this.updateUI();
        alert('Settings reset to defaults.');
      }
    });

    document.getElementById('exportBtn').addEventListener('click', async () => {
      try {
        const result = await chrome.storage.local.get('acgEvents');
        const events = result.acgEvents || [];
        
        const exportData = {
          exportDate: new Date().toISOString(),
          version: '1.2.1',
          totalEvents: events.length,
          events: events
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `ai-context-guard-events-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch (error) {
        console.error('[AI Context Guard Options] Error exporting:', error);
        alert('Failed to export events.');
      }
    });

    // Footer links
    document.getElementById('privacyLink').addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: 'https://github.com/AgroTrack/ai-context-guard#privacy' });
    });

    document.getElementById('supportLink').addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: 'https://github.com/AgroTrack/ai-context-guard/issues' });
    });

    document.getElementById('githubLink').addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: 'https://github.com/AgroTrack/ai-context-guard' });
    });
  }

  async saveConfig(updates) {
    try {
      const newConfig = { ...this.config, ...updates };
      await chrome.storage.local.set({ acgConfig: newConfig });
      this.config = newConfig;
      // Storage listener in content scripts will automatically pick up changes
    } catch (error) {
      console.error('[AI Context Guard Options] Error saving config:', error);
    }
  }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  new OptionsManager();
});
