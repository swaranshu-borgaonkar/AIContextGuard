// AI Context Guard - Popup Script v1.2.0

class PopupManager {
  constructor() {
    this.config = {
      enableWarnings: true,
      enableAutoRedact: true,
      enableLogging: true
    };
    this.events = [];
    this.init();
  }

  async init() {
    await this.loadData();
    this.setupEventListeners();
    this.setupStorageListener();
    this.loadPlatformCount();
  }

  async loadPlatformCount() {
    try {
      const manifest = chrome.runtime.getManifest();
      const matches = manifest.content_scripts?.[0]?.matches || [];
      // Count unique domains
      const domains = new Set();
      matches.forEach(match => {
        const domain = match.replace(/^\*:\/\//, '').replace(/\/\*$/, '').replace(/^\*\./, '');
        domains.add(domain);
      });
      document.getElementById('platformCount').textContent = `${domains.size} AI platforms`;
    } catch (e) {
      document.getElementById('platformCount').textContent = '26 AI platforms';
    }
  }

  async loadData() {
    try {
      // Load config
      const configResult = await chrome.storage.local.get('acgConfig');
      if (configResult.acgConfig) {
        this.config = { ...this.config, ...configResult.acgConfig };
      }
      this.updateToggles();

      // Load events
      const eventsResult = await chrome.storage.local.get('acgEvents');
      this.events = eventsResult.acgEvents || [];
      this.updateStats();
      this.updateEventsList();
    } catch (error) {
      console.error('[AI Context Guard Popup] Error loading data:', error);
    }
  }

  setupStorageListener() {
    // Listen for storage changes instead of polling
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      
      if (changes.acgConfig) {
        this.config = { ...this.config, ...changes.acgConfig.newValue };
        this.updateToggles();
      }
      
      if (changes.acgEvents) {
        this.events = changes.acgEvents.newValue || [];
        this.updateStats();
        this.updateEventsList();
      }
    });
  }

  updateStats() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayEvents = this.events.filter(event => {
      const eventDate = new Date(event.timestamp);
      eventDate.setHours(0, 0, 0, 0);
      return eventDate.getTime() === today.getTime();
    });

    const criticalCount = todayEvents.reduce((sum, e) => sum + (e.critical || 0), 0);
    const highCount = todayEvents.reduce((sum, e) => sum + (e.high || 0), 0);
    const redactedCount = todayEvents.filter(e => e.action === 'redacted').length;

    document.getElementById('criticalCount').textContent = criticalCount;
    document.getElementById('highCount').textContent = highCount;
    document.getElementById('redactedCount').textContent = redactedCount;
    document.getElementById('totalCount').textContent = this.events.length;
  }

  updateToggles() {
    document.getElementById('enableWarnings').checked = this.config.enableWarnings !== false;
    document.getElementById('enableAutoRedact').checked = this.config.enableAutoRedact !== false;
    document.getElementById('enableLogging').checked = this.config.enableLogging !== false;
  }

  updateEventsList() {
    const container = document.getElementById('eventsList');
    const recentEvents = this.events.slice(-10).reverse();

    if (recentEvents.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📋</div>
          <div class="empty-state-text">No events yet</div>
        </div>
      `;
      return;
    }

    container.innerHTML = recentEvents.map(event => {
      const time = new Date(event.timestamp);
      const timeStr = time.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });

      const actionClass = event.action || 'unknown';
      const types = (event.types || []).slice(0, 3);
      const moreTypes = (event.types || []).length > 3 ? `+${event.types.length - 3}` : '';

      return `
        <div class="event-item">
          <div class="event-header">
            <span class="event-action ${actionClass}">${(event.action || 'detected').toUpperCase()}</span>
            <span class="event-time">${timeStr}</span>
          </div>
          <div class="event-details">
            ${event.findingsCount || 0} items detected (${event.critical || 0} critical, ${event.high || 0} high)
          </div>
          <div class="event-types">
            ${types.map(t => `<span class="event-type-tag">${t}</span>`).join('')}
            ${moreTypes ? `<span class="event-type-tag">${moreTypes}</span>` : ''}
          </div>
        </div>
      `;
    }).join('');
  }

  setupEventListeners() {
    // Toggle handlers
    document.getElementById('enableWarnings').addEventListener('change', (e) => {
      this.saveConfig({ enableWarnings: e.target.checked });
    });

    document.getElementById('enableAutoRedact').addEventListener('change', (e) => {
      this.saveConfig({ enableAutoRedact: e.target.checked });
    });

    document.getElementById('enableLogging').addEventListener('change', (e) => {
      this.saveConfig({ enableLogging: e.target.checked });
    });

    // Button handlers
    document.getElementById('clearBtn').addEventListener('click', () => {
      if (confirm('Clear all detection events? This cannot be undone.')) {
        chrome.storage.local.set({ acgEvents: [] }, () => {
          this.events = [];
          this.updateStats();
          this.updateEventsList();
        });
      }
    });

    document.getElementById('settingsBtn').addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
    });

    document.getElementById('privacyLink').addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: 'https://github.com/AgroTrack/ai-context-guard#privacy' });
    });
  }

  async saveConfig(updates) {
    try {
      const result = await chrome.storage.local.get('acgConfig');
      const currentConfig = result.acgConfig || {
        enableWarnings: true,
        enableAutoRedact: true,
        enableLogging: true,
        scanDelay: 300
      };

      const newConfig = { ...currentConfig, ...updates };
      await chrome.storage.local.set({ acgConfig: newConfig });
      this.config = newConfig;
      // Storage listener will propagate to content scripts automatically
    } catch (error) {
      console.error('[AI Context Guard Popup] Error saving config:', error);
    }
  }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  new PopupManager();
});
