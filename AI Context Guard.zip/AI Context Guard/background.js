// AI Context Guard - Background Service Worker v1.2.0
// Handles storage, badge updates, and cleanup

const DEFAULT_CONFIG = {
  enableWarnings: true,
  enableAutoRedact: true,
  enableLogging: true,
  scanDelay: 300
};

// Initialize extension on install
chrome.runtime.onInstalled.addListener((details) => {
  console.log('[AI Context Guard] Extension installed/updated:', details.reason);
  
  // Initialize storage with defaults
  chrome.storage.local.get(['acgConfig', 'acgEvents'], (result) => {
    if (!result.acgConfig) {
      chrome.storage.local.set({ acgConfig: DEFAULT_CONFIG });
    }
    if (!result.acgEvents) {
      chrome.storage.local.set({ acgEvents: [] });
    }
  });

  // Set up daily cleanup alarm
  chrome.alarms.create('cleanupOldEvents', { periodInMinutes: 1440 });
});

// Handle alarms
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'cleanupOldEvents') {
    cleanupOldEvents();
  }
});

// Clean up events older than 30 days
function cleanupOldEvents() {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  chrome.storage.local.get('acgEvents', (result) => {
    const events = result.acgEvents || [];
    const filteredEvents = events.filter(event => {
      const eventDate = new Date(event.timestamp);
      return eventDate > thirtyDaysAgo;
    });

    if (filteredEvents.length !== events.length) {
      chrome.storage.local.set({ acgEvents: filteredEvents });
      console.log('[AI Context Guard] Cleaned up', events.length - filteredEvents.length, 'old events');
    }
  });
}

// Update badge when storage changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.acgEvents) {
    updateBadge(changes.acgEvents.newValue || []);
  }
});

// Update extension badge
function updateBadge(events) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const todayBlocks = events.filter(e => {
    const eventDate = new Date(e.timestamp);
    eventDate.setHours(0, 0, 0, 0);
    return eventDate.getTime() === today.getTime() && 
           (e.action === 'redacted' || e.action === 'cancelled');
  }).length;

  if (todayBlocks > 0) {
    chrome.action.setBadgeText({ text: String(todayBlocks) });
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// Initialize badge on startup
chrome.runtime.onStartup.addListener(() => {
  console.log('[AI Context Guard] Extension started');
  chrome.storage.local.get('acgEvents', (result) => {
    updateBadge(result.acgEvents || []);
  });
});

// Also initialize badge immediately
chrome.storage.local.get('acgEvents', (result) => {
  updateBadge(result.acgEvents || []);
});

console.log('[AI Context Guard] Background service worker loaded');
