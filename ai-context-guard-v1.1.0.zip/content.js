// AI Context Guard - Content Script v1.1.0
// Fully compatible with ChatGPT, Claude, Gemini, Copilot, Perplexity, and all AI platforms
// Handles textarea, input, contenteditable, ProseMirror, CodeMirror, and custom editors

(function() {
  'use strict';

  // Prevent multiple initializations
  if (window.__AIContextGuardInitialized) {
    return;
  }
  window.__AIContextGuardInitialized = true;

  class SensitiveDataDetector {
    constructor() {
      this.patterns = {
        // Cloud Provider Keys
        aws_access_key: {
          regex: /(?:A3T[A-Z0-9]|AKIA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}/g,
          severity: 'CRITICAL',
          label: 'AWS Access Key'
        },
        aws_secret_key: {
          regex: /(?:aws_secret_access_key|aws_secret_key|AWS_SECRET)\s*[=:]\s*['"]?([A-Za-z0-9\/+=]{40})['"]?/gi,
          severity: 'CRITICAL',
          label: 'AWS Secret Key'
        },
        azure_key: {
          regex: /(?:AccountKey|azure[_-]?(?:storage[_-]?)?key)\s*[=:]\s*['"]?([A-Za-z0-9+\/=]{88})['"]?/gi,
          severity: 'CRITICAL',
          label: 'Azure Storage Key'
        },
        gcp_api_key: {
          regex: /AIza[0-9A-Za-z_-]{35}/g,
          severity: 'CRITICAL',
          label: 'Google Cloud API Key'
        },
        gcp_service_account: {
          regex: /"type"\s*:\s*"service_account"/g,
          severity: 'CRITICAL',
          label: 'GCP Service Account'
        },

        // API Keys & Tokens
        openai_key: {
          regex: /sk-[A-Za-z0-9]{48}/g,
          severity: 'CRITICAL',
          label: 'OpenAI API Key'
        },
        anthropic_key: {
          regex: /sk-ant-[A-Za-z0-9-]{95}/g,
          severity: 'CRITICAL',
          label: 'Anthropic API Key'
        },
        github_token: {
          regex: /ghp_[A-Za-z0-9]{36}/g,
          severity: 'CRITICAL',
          label: 'GitHub Token'
        },
        github_pat: {
          regex: /github_pat_[A-Za-z0-9_]{22,}_[A-Za-z0-9]{59,}/g,
          severity: 'CRITICAL',
          label: 'GitHub PAT'
        },
        gitlab_token: {
          regex: /glpat-[A-Za-z0-9_-]{20}/g,
          severity: 'CRITICAL',
          label: 'GitLab Token'
        },
        slack_token: {
          regex: /xox[baprs]-[0-9]{10,13}-[0-9]{10,13}[a-zA-Z0-9-]*/g,
          severity: 'CRITICAL',
          label: 'Slack Token'
        },
        slack_webhook: {
          regex: /https:\/\/hooks\.slack\.com\/services\/T[A-Z0-9]+\/B[A-Z0-9]+\/[A-Za-z0-9]+/g,
          severity: 'CRITICAL',
          label: 'Slack Webhook'
        },
        stripe_key: {
          regex: /(?:sk|pk)_(?:live|test)_[0-9a-zA-Z]{24,}/g,
          severity: 'CRITICAL',
          label: 'Stripe Key'
        },
        twilio_key: {
          regex: /SK[0-9a-fA-F]{32}/g,
          severity: 'CRITICAL',
          label: 'Twilio API Key'
        },
        sendgrid_key: {
          regex: /SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}/g,
          severity: 'CRITICAL',
          label: 'SendGrid API Key'
        },
        mailchimp_key: {
          regex: /[a-f0-9]{32}-us[0-9]{1,2}/g,
          severity: 'HIGH',
          label: 'Mailchimp API Key'
        },
        npm_token: {
          regex: /npm_[A-Za-z0-9]{36}/g,
          severity: 'CRITICAL',
          label: 'NPM Token'
        },
        pypi_token: {
          regex: /pypi-[A-Za-z0-9_-]{100,}/g,
          severity: 'CRITICAL',
          label: 'PyPI Token'
        },
        docker_token: {
          regex: /dckr_pat_[A-Za-z0-9_-]{27}/g,
          severity: 'CRITICAL',
          label: 'Docker Token'
        },

        // Generic API Keys
        api_key_generic: {
          regex: /(?:api[_-]?key|apikey|access[_-]?key)\s*[=:]\s*['"]([A-Za-z0-9_-]{20,})['"]?/gi,
          severity: 'HIGH',
          label: 'API Key'
        },
        bearer_token: {
          regex: /[Bb]earer\s+[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g,
          severity: 'HIGH',
          label: 'Bearer Token'
        },
        basic_auth: {
          regex: /[Bb]asic\s+[A-Za-z0-9+\/=]{20,}/g,
          severity: 'HIGH',
          label: 'Basic Auth'
        },

        // Cryptographic
        jwt_token: {
          regex: /eyJ[A-Za-z0-9_-]*\.eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*/g,
          severity: 'HIGH',
          label: 'JWT Token'
        },
        private_key_header: {
          regex: /-----BEGIN\s+(?:RSA\s+)?PRIVATE\s+KEY-----/g,
          severity: 'CRITICAL',
          label: 'Private Key'
        },
        private_key_full: {
          regex: /-----BEGIN\s+(?:RSA\s+|EC\s+|DSA\s+|OPENSSH\s+|PGP\s+)?PRIVATE\s+KEY-----[\s\S]*?-----END\s+(?:RSA\s+|EC\s+|DSA\s+|OPENSSH\s+|PGP\s+)?PRIVATE\s+KEY-----/g,
          severity: 'CRITICAL',
          label: 'Private Key Block'
        },
        ssh_private_key: {
          regex: /-----BEGIN\s+OPENSSH\s+PRIVATE\s+KEY-----/g,
          severity: 'CRITICAL',
          label: 'SSH Private Key'
        },
        pgp_private_key: {
          regex: /-----BEGIN\s+PGP\s+PRIVATE\s+KEY\s+BLOCK-----/g,
          severity: 'CRITICAL',
          label: 'PGP Private Key'
        },

        // Database
        db_connection_string: {
          regex: /(?:mongodb(?:\+srv)?|mysql|postgresql|postgres|redis|mssql|oracle):\/\/[^\s'"]+/gi,
          severity: 'CRITICAL',
          label: 'Database Connection'
        },
        db_password: {
          regex: /(?:password|passwd|pwd|db_pass|database_password)\s*[=:]\s*['"]([^'"]{8,})['"]?/gi,
          severity: 'CRITICAL',
          label: 'Database Password'
        },

        // PII - Personal Identifiable Information
        ssn: {
          regex: /\b(?!000|666|9\d{2})\d{3}[-\s]?(?!00)\d{2}[-\s]?(?!0000)\d{4}\b/g,
          severity: 'CRITICAL',
          label: 'Social Security Number'
        },
        credit_card: {
          regex: /\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})\b/g,
          severity: 'CRITICAL',
          label: 'Credit Card Number'
        },
        credit_card_formatted: {
          regex: /\b(?:\d{4}[-\s]?){3}\d{4}\b/g,
          severity: 'HIGH',
          label: 'Credit Card (Formatted)'
        },
        iban: {
          regex: /\b[A-Z]{2}[0-9]{2}[A-Z0-9]{4}[0-9]{7}(?:[A-Z0-9]?){0,16}\b/g,
          severity: 'CRITICAL',
          label: 'IBAN'
        },
        swift_code: {
          regex: /\b[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}(?:[A-Z0-9]{3})?\b/g,
          severity: 'HIGH',
          label: 'SWIFT Code'
        },
        passport: {
          regex: /(?:passport\s*(?:number|no|#)?)\s*[=:]\s*['"]?([A-Z0-9]{6,12})['"]?/gi,
          severity: 'HIGH',
          label: 'Passport Number'
        },
        drivers_license: {
          regex: /(?:driver'?s?\s*licen[sc]e|DL)\s*(?:number|no|#)?\s*[=:]\s*['"]?([A-Z0-9]{5,15})['"]?/gi,
          severity: 'HIGH',
          label: 'Drivers License'
        },
        phone_us: {
          regex: /\b(?:\+?1[-.\s]?)?\(?[2-9][0-9]{2}\)?[-.\s]?[2-9][0-9]{2}[-.\s]?[0-9]{4}\b/g,
          severity: 'MEDIUM',
          label: 'US Phone Number'
        },
        phone_intl: {
          regex: /\b\+[1-9][0-9]{7,14}\b/g,
          severity: 'MEDIUM',
          label: 'International Phone'
        },
        email: {
          regex: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g,
          severity: 'MEDIUM',
          label: 'Email Address'
        },

        // Healthcare
        medical_record: {
          regex: /(?:mrn|medical\s*record\s*(?:number|no|#)?)\s*[=:]\s*['"]?([A-Z0-9]{5,15})['"]?/gi,
          severity: 'CRITICAL',
          label: 'Medical Record Number'
        },
        health_insurance_id: {
          regex: /(?:insurance\s*id|policy\s*(?:number|no)|member\s*id)\s*[=:]\s*['"]?([A-Z0-9]{5,20})['"]?/gi,
          severity: 'CRITICAL',
          label: 'Health Insurance ID'
        },
        npi: {
          regex: /\b[12][0-9]{9}\b/g,
          severity: 'HIGH',
          label: 'NPI Number'
        },

        // Infrastructure
        internal_ip: {
          regex: /\b(?:10\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|172\.(?:1[6-9]|2[0-9]|3[0-1])\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|192\.168\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))\b/g,
          severity: 'HIGH',
          label: 'Internal IP Address'
        },
        localhost: {
          regex: /\b(?:localhost|127\.0\.0\.1)(?::\d+)?\b/g,
          severity: 'MEDIUM',
          label: 'Localhost'
        },
        internal_url: {
          regex: /https?:\/\/(?:internal|staging|dev|local|vpn|admin|intranet|corp|private)\.[a-z0-9][a-z0-9-]*\.[a-z]{2,}/gi,
          severity: 'HIGH',
          label: 'Internal URL'
        },
        aws_s3_url: {
          regex: /https?:\/\/[a-z0-9][a-z0-9.-]*\.s3[.-][a-z0-9-]*\.amazonaws\.com/gi,
          severity: 'HIGH',
          label: 'AWS S3 URL'
        },
        aws_arn: {
          regex: /arn:aws:[a-z0-9-]+:[a-z0-9-]*:[0-9]*:[a-z0-9-\/]+/gi,
          severity: 'HIGH',
          label: 'AWS ARN'
        },

        // Environment Variables & Config
        env_variable: {
          regex: /(?:DATABASE_URL|REDIS_URL|MONGO_URL|MONGODB_URI|API_URL|SECRET_KEY|PRIVATE_KEY|AUTH_TOKEN|ACCESS_TOKEN|REFRESH_TOKEN|SESSION_SECRET|ENCRYPTION_KEY)\s*[=:]\s*['"]?[^\s'"]+['"]?/gi,
          severity: 'HIGH',
          label: 'Environment Variable'
        },
        hardcoded_password: {
          regex: /(?:password|passwd|pwd|secret|api_key|apikey|auth_token|access_token)\s*[=:]\s*['"`]([^'"`\s]{8,})['"`]/gi,
          severity: 'HIGH',
          label: 'Hardcoded Secret'
        },

        // Additional Service Keys
        datadog_api_key: {
          regex: /(?:DD_API_KEY|datadog_api_key)\s*[=:]\s*['"]?([a-f0-9]{32})['"]?/gi,
          severity: 'CRITICAL',
          label: 'Datadog API Key'
        },
        new_relic_key: {
          regex: /NRAK-[A-Z0-9]{27}/g,
          severity: 'CRITICAL',
          label: 'New Relic Key'
        },
        vault_token: {
          regex: /hvs\.[a-zA-Z0-9_-]{90,}/g,
          severity: 'CRITICAL',
          label: 'Vault Token'
        },
        firebase_key: {
          regex: /AAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}/g,
          severity: 'CRITICAL',
          label: 'Firebase Key'
        },
        shopify_token: {
          regex: /shpat_[a-fA-F0-9]{32}/g,
          severity: 'CRITICAL',
          label: 'Shopify Token'
        },
        square_token: {
          regex: /sq0[a-z]{3}-[A-Za-z0-9_-]{22,}/g,
          severity: 'CRITICAL',
          label: 'Square Token'
        }
      };
    }

    detect(text) {
      if (!text || typeof text !== 'string' || text.trim().length === 0) {
        return [];
      }

      const findings = [];
      const seen = new Set();

      for (const [patternName, patternConfig] of Object.entries(this.patterns)) {
        // Reset regex lastIndex for global patterns
        patternConfig.regex.lastIndex = 0;
        
        let match;
        while ((match = patternConfig.regex.exec(text)) !== null) {
          const value = match[1] || match[0]; // Use captured group if available
          const uniqueKey = `${patternName}:${value}`;
          
          if (!seen.has(uniqueKey) && this.isValidMatch(patternName, value)) {
            seen.add(uniqueKey);
            findings.push({
              type: patternName,
              label: patternConfig.label,
              value: value,
              redactedValue: this.redactValue(value),
              severity: patternConfig.severity,
              startIndex: match.index,
              endIndex: match.index + match[0].length,
              fullMatch: match[0]
            });
          }
        }
      }

      return findings.sort((a, b) => {
        const severityOrder = { 'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3 };
        return severityOrder[a.severity] - severityOrder[b.severity];
      });
    }

    isValidMatch(patternName, value) {
      // Filter out common false positives
      if (!value || value.length < 4) return false;
      
      // Skip common placeholder values
      const placeholders = ['example', 'your-', 'xxx', 'test', 'demo', 'sample', 'placeholder', 'changeme'];
      const lowerValue = value.toLowerCase();
      if (placeholders.some(p => lowerValue.includes(p))) return false;

      // Additional validation for specific patterns
      switch (patternName) {
        case 'credit_card':
        case 'credit_card_formatted':
          return this.luhnCheck(value.replace(/[-\s]/g, ''));
        case 'email':
          // Skip common test/example emails
          return !/(example|test|sample|noreply|no-reply)/.test(lowerValue);
        case 'phone_us':
        case 'phone_intl':
          // Skip obviously fake numbers
          return !/^(?:0{10}|1{10}|123456|555-555|000-000)/.test(value.replace(/[-.\s()]/g, ''));
        default:
          return true;
      }
    }

    luhnCheck(num) {
      const digits = num.replace(/\D/g, '');
      if (digits.length < 13 || digits.length > 19) return false;
      
      let sum = 0;
      let isEven = false;
      
      for (let i = digits.length - 1; i >= 0; i--) {
        let digit = parseInt(digits[i], 10);
        if (isEven) {
          digit *= 2;
          if (digit > 9) digit -= 9;
        }
        sum += digit;
        isEven = !isEven;
      }
      
      return sum % 10 === 0;
    }

    redactValue(value) {
      if (!value) return '[REDACTED]';
      const len = value.length;
      if (len <= 4) return '*'.repeat(len);
      if (len <= 8) return value.substring(0, 2) + '*'.repeat(len - 2);
      return value.substring(0, 3) + '*'.repeat(Math.min(len - 6, 20)) + value.substring(len - 3);
    }

    scrubText(text, findings) {
      if (!findings || findings.length === 0) return text;
      
      let result = text;
      // Sort by position descending to replace from end to start
      const sortedFindings = [...findings].sort((a, b) => b.startIndex - a.startIndex);
      
      for (const finding of sortedFindings) {
        const before = result.substring(0, finding.startIndex);
        const after = result.substring(finding.endIndex);
        result = before + '[REDACTED]' + after;
      }
      
      return result;
    }
  }

  class AIContextGuard {
    constructor() {
      this.detector = new SensitiveDataDetector();
      this.warningOverlay = null;
      this.isWarningShown = false;
      this.scanTimeout = null;
      this.observer = null;
      this.processedElements = new WeakSet();
      
      this.config = {
        enableWarnings: true,
        enableAutoRedact: true,
        enableLogging: true,
        scanDelay: 300
      };

      this.platformSelectors = this.getPlatformSelectors();
      this.init();
    }

    getPlatformSelectors() {
      // Platform-specific input selectors
      return {
        // ChatGPT
        'chatgpt.com': [
          'textarea[data-id="root"]',
          'textarea#prompt-textarea',
          'div[contenteditable="true"]',
          '#prompt-textarea'
        ],
        'chat.openai.com': [
          'textarea[data-id="root"]',
          'textarea#prompt-textarea',
          'div[contenteditable="true"]',
          '#prompt-textarea'
        ],
        // Claude
        'claude.ai': [
          'div[contenteditable="true"]',
          'div.ProseMirror',
          '[contenteditable="true"]',
          'fieldset div[contenteditable]',
          'div[data-placeholder]'
        ],
        // Gemini
        'gemini.google.com': [
          'div[contenteditable="true"]',
          'rich-textarea div[contenteditable]',
          '.ql-editor',
          'div[role="textbox"]'
        ],
        'bard.google.com': [
          'div[contenteditable="true"]',
          'rich-textarea div[contenteditable]',
          '.ql-editor',
          'div[role="textbox"]'
        ],
        // Copilot
        'copilot.microsoft.com': [
          'textarea',
          'div[contenteditable="true"]',
          '#searchbox',
          'cib-serp textarea'
        ],
        // Perplexity
        'perplexity.ai': [
          'textarea',
          'div[contenteditable="true"]',
          '[data-testid="query-input"]'
        ],
        'www.perplexity.ai': [
          'textarea',
          'div[contenteditable="true"]',
          '[data-testid="query-input"]'
        ],
        // Poe
        'poe.com': [
          'textarea',
          'div[contenteditable="true"]',
          '.GrowingTextArea_textArea__eadlu'
        ],
        // You.com
        'you.com': [
          'textarea',
          'div[contenteditable="true"]',
          'input[type="text"]'
        ],
        // HuggingFace
        'huggingface.co': [
          'textarea',
          'div[contenteditable="true"]'
        ],
        // Mistral
        'chat.mistral.ai': [
          'textarea',
          'div[contenteditable="true"]'
        ],
        // Default fallback
        'default': [
          'textarea',
          'input[type="text"]',
          'input[type="search"]',
          'div[contenteditable="true"]',
          '[contenteditable="true"]',
          'div[role="textbox"]',
          '.ProseMirror',
          '.CodeMirror',
          '.ql-editor'
        ]
      };
    }

    init() {
      this.loadConfig();
      this.setupEventListeners();
      this.setupMutationObserver();
      this.injectStyles();
      console.log('[AI Context Guard] Initialized on', window.location.hostname);
    }

    loadConfig() {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.get('acgConfig', (result) => {
          if (result && result.acgConfig) {
            this.config = { ...this.config, ...result.acgConfig };
          }
        });

        chrome.storage.onChanged.addListener((changes) => {
          if (changes.acgConfig) {
            this.config = { ...this.config, ...changes.acgConfig.newValue };
          }
        });
      }
    }

    setupEventListeners() {
      // Use capture phase to intercept events before they reach the target
      document.addEventListener('paste', (e) => this.handlePaste(e), true);
      document.addEventListener('input', (e) => this.handleInput(e), true);
      document.addEventListener('beforeinput', (e) => this.handleBeforeInput(e), true);
      document.addEventListener('keydown', (e) => this.handleKeydown(e), true);
      
      // Listen for config updates from popup/options
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
          if (request.type === 'CONFIG_UPDATE') {
            this.config = { ...this.config, ...request.config };
            sendResponse({ success: true });
          }
          return true;
        });
      }
    }

    setupMutationObserver() {
      // Watch for dynamically added input elements
      this.observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              this.processNewElement(node);
            }
          }
        }
      });

      this.observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true
      });
    }

    processNewElement(element) {
      if (this.processedElements.has(element)) return;
      
      if (this.isRelevantInput(element)) {
        this.processedElements.add(element);
      }
      
      // Check children as well
      const inputs = element.querySelectorAll ? 
        element.querySelectorAll('textarea, [contenteditable="true"], input[type="text"]') : [];
      inputs.forEach(input => {
        if (!this.processedElements.has(input)) {
          this.processedElements.add(input);
        }
      });
    }

    getHostname() {
      return window.location.hostname.replace(/^www\./, '');
    }

    isRelevantInput(element) {
      if (!element || !element.tagName) return false;

      const tagName = element.tagName.toLowerCase();
      const isTextarea = tagName === 'textarea';
      const isTextInput = tagName === 'input' && 
        ['text', 'search', 'email', 'url', 'tel'].includes((element.type || '').toLowerCase());
      const isContentEditable = element.isContentEditable || 
        element.contentEditable === 'true' ||
        element.getAttribute('contenteditable') === 'true';
      const isProseMirror = element.classList && element.classList.contains('ProseMirror');
      const isRoleTextbox = element.getAttribute('role') === 'textbox';

      return isTextarea || isTextInput || isContentEditable || isProseMirror || isRoleTextbox;
    }

    getInputSelectors() {
      const hostname = this.getHostname();
      return this.platformSelectors[hostname] || this.platformSelectors['default'];
    }

    findInputElement(target) {
      // Check if target itself is an input
      if (this.isRelevantInput(target)) {
        return target;
      }

      // Check parents
      let current = target;
      while (current && current !== document.body) {
        if (this.isRelevantInput(current)) {
          return current;
        }
        current = current.parentElement;
      }

      // Check children (for wrapper elements)
      if (target.querySelector) {
        const selectors = this.getInputSelectors();
        for (const selector of selectors) {
          const found = target.querySelector(selector);
          if (found) return found;
        }
      }

      return null;
    }

    getElementText(element) {
      if (!element) return '';

      // For standard form elements
      if (element.value !== undefined && element.tagName.toLowerCase() !== 'div') {
        return element.value || '';
      }

      // For contenteditable, ProseMirror, etc.
      if (element.isContentEditable || element.contentEditable === 'true') {
        return element.innerText || element.textContent || '';
      }

      // For elements with role="textbox"
      if (element.getAttribute('role') === 'textbox') {
        return element.innerText || element.textContent || '';
      }

      // Fallback
      return element.value || element.innerText || element.textContent || '';
    }

    setElementText(element, text) {
      if (!element) return;

      // For standard form elements
      if (element.value !== undefined && element.tagName.toLowerCase() !== 'div') {
        element.value = text;
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        return;
      }

      // For contenteditable elements
      if (element.isContentEditable || element.contentEditable === 'true') {
        // Clear existing content
        element.innerHTML = '';
        
        // Insert new text
        if (text) {
          const textNode = document.createTextNode(text);
          element.appendChild(textNode);
          
          // Move cursor to end
          const range = document.createRange();
          const selection = window.getSelection();
          range.selectNodeContents(element);
          range.collapse(false);
          selection.removeAllRanges();
          selection.addRange(range);
        }

        // Dispatch events
        element.dispatchEvent(new InputEvent('input', { 
          bubbles: true, 
          cancelable: true,
          inputType: 'insertText',
          data: text
        }));
        return;
      }

      // Fallback
      if (element.value !== undefined) {
        element.value = text;
      } else {
        element.textContent = text;
      }
      element.dispatchEvent(new Event('input', { bubbles: true }));
    }

    handlePaste(event) {
      if (!this.config.enableWarnings) return;

      const target = this.findInputElement(event.target);
      if (!target) return;

      const clipboardData = event.clipboardData || window.clipboardData;
      if (!clipboardData) return;

      const pastedText = clipboardData.getData('text');
      if (!pastedText || pastedText.trim().length === 0) return;

      const findings = this.detector.detect(pastedText);
      
      if (findings.length > 0) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        this.showWarning(findings, pastedText, target, 'paste');
      }
    }

    handleInput(event) {
      if (!this.config.enableWarnings) return;

      const target = this.findInputElement(event.target);
      if (!target) return;

      // Debounce the scan
      clearTimeout(this.scanTimeout);
      this.scanTimeout = setTimeout(() => {
        const text = this.getElementText(target);
        if (text && text.trim().length > 0) {
          const findings = this.detector.detect(text);
          if (findings.length > 0 && !this.isWarningShown) {
            this.showWarning(findings, text, target, 'input');
          }
        }
      }, this.config.scanDelay);
    }

    handleBeforeInput(event) {
      // Additional safeguard for insert operations
      if (!this.config.enableWarnings) return;
      
      if (event.inputType === 'insertFromPaste' && event.data) {
        const findings = this.detector.detect(event.data);
        if (findings.length > 0) {
          event.preventDefault();
          const target = this.findInputElement(event.target);
          if (target) {
            this.showWarning(findings, event.data, target, 'paste');
          }
        }
      }
    }

    handleKeydown(event) {
      // Intercept Ctrl+V / Cmd+V as additional safeguard
      if ((event.ctrlKey || event.metaKey) && event.key === 'v') {
        // Let the paste event handler deal with it
        return;
      }

      // Intercept Enter key if warning is shown
      if (event.key === 'Enter' && this.isWarningShown) {
        event.preventDefault();
        event.stopPropagation();
      }
    }

    showWarning(findings, text, targetElement, source) {
      if (this.isWarningShown) return;
      this.isWarningShown = true;

      const criticalCount = findings.filter(f => f.severity === 'CRITICAL').length;
      const highCount = findings.filter(f => f.severity === 'HIGH').length;
      const mediumCount = findings.filter(f => f.severity === 'MEDIUM').length;

      // Create overlay
      this.warningOverlay = document.createElement('div');
      this.warningOverlay.id = 'acg-warning-overlay';
      this.warningOverlay.className = criticalCount > 0 ? 'acg-severity-critical' : 'acg-severity-high';
      
      const findingsHtml = findings.slice(0, 5).map(f => 
        `<span class="acg-finding-tag acg-severity-${f.severity.toLowerCase()}">${f.label}</span>`
      ).join('');
      const moreCount = findings.length > 5 ? `<span class="acg-finding-more">+${findings.length - 5} more</span>` : '';

      this.warningOverlay.innerHTML = `
        <div class="acg-warning-modal">
          <div class="acg-warning-header ${criticalCount > 0 ? 'acg-critical' : 'acg-high'}">
            <span class="acg-warning-icon">⚠️</span>
            <span class="acg-warning-title">Sensitive Data Detected!</span>
            <button class="acg-close-btn" id="acg-close-btn">&times;</button>
          </div>
          <div class="acg-warning-body">
            <p class="acg-warning-message">
              AI Context Guard detected <strong>${findings.length}</strong> sensitive item(s) that may leak confidential data:
            </p>
            <div class="acg-severity-summary">
              ${criticalCount > 0 ? `<span class="acg-severity-badge acg-critical">${criticalCount} CRITICAL</span>` : ''}
              ${highCount > 0 ? `<span class="acg-severity-badge acg-high">${highCount} HIGH</span>` : ''}
              ${mediumCount > 0 ? `<span class="acg-severity-badge acg-medium">${mediumCount} MEDIUM</span>` : ''}
            </div>
            <div class="acg-findings-list">
              ${findingsHtml}
              ${moreCount}
            </div>
          </div>
          <div class="acg-warning-actions">
            <button class="acg-btn acg-btn-redact" id="acg-redact-btn">
              <span>🔒</span> Auto-Redact & Continue
            </button>
            <button class="acg-btn acg-btn-cancel" id="acg-cancel-btn">
              <span>❌</span> Cancel
            </button>
            <button class="acg-btn acg-btn-force" id="acg-force-btn">
              <span>⚡</span> Send Anyway
            </button>
          </div>
          <div class="acg-warning-footer">
            <span>🛡️ AI Context Guard v1.1.0</span>
          </div>
        </div>
      `;

      document.body.appendChild(this.warningOverlay);

      // Event handlers
      document.getElementById('acg-redact-btn').onclick = () => {
        const scrubbedText = this.detector.scrubText(text, findings);
        this.setElementText(targetElement, scrubbedText);
        this.logEvent('redacted', findings, source);
        this.closeWarning();
      };

      document.getElementById('acg-cancel-btn').onclick = () => {
        if (source === 'paste') {
          // Don't modify existing content for paste cancel
        } else {
          this.setElementText(targetElement, '');
        }
        this.logEvent('cancelled', findings, source);
        this.closeWarning();
        targetElement.focus();
      };

      document.getElementById('acg-force-btn').onclick = () => {
        if (source === 'paste') {
          // Insert the original text
          this.setElementText(targetElement, this.getElementText(targetElement) + text);
        }
        this.logEvent('forced', findings, source);
        this.closeWarning();
        targetElement.focus();
      };

      document.getElementById('acg-close-btn').onclick = () => {
        this.logEvent('dismissed', findings, source);
        this.closeWarning();
      };

      // Close on escape key
      const escHandler = (e) => {
        if (e.key === 'Escape') {
          this.logEvent('dismissed', findings, source);
          this.closeWarning();
          document.removeEventListener('keydown', escHandler);
        }
      };
      document.addEventListener('keydown', escHandler);

      // Close on overlay click
      this.warningOverlay.onclick = (e) => {
        if (e.target === this.warningOverlay) {
          this.logEvent('dismissed', findings, source);
          this.closeWarning();
        }
      };
    }

    closeWarning() {
      if (this.warningOverlay && this.warningOverlay.parentNode) {
        this.warningOverlay.parentNode.removeChild(this.warningOverlay);
      }
      this.warningOverlay = null;
      this.isWarningShown = false;
    }

    logEvent(action, findings, source) {
      if (!this.config.enableLogging) return;

      const event = {
        timestamp: new Date().toISOString(),
        action: action,
        source: source,
        url: window.location.href,
        hostname: window.location.hostname,
        findingsCount: findings.length,
        critical: findings.filter(f => f.severity === 'CRITICAL').length,
        high: findings.filter(f => f.severity === 'HIGH').length,
        medium: findings.filter(f => f.severity === 'MEDIUM').length,
        types: [...new Set(findings.map(f => f.label))]
      };

      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.get('acgEvents', (result) => {
          const events = result.acgEvents || [];
          events.push(event);
          // Keep only last 1000 events
          if (events.length > 1000) {
            events.splice(0, events.length - 1000);
          }
          chrome.storage.local.set({ acgEvents: events });
        });
      }

      console.log('[AI Context Guard]', action.toUpperCase(), '- Found:', findings.length, 'sensitive items');
    }

    injectStyles() {
      // Styles are loaded from content.css, but add critical inline styles as backup
      const style = document.createElement('style');
      style.textContent = `
        #acg-warning-overlay {
          position: fixed !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          bottom: 0 !important;
          background: rgba(0, 0, 0, 0.75) !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          z-index: 2147483647 !important;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
        }
      `;
      document.head.appendChild(style);
    }
  }

  // Initialize when DOM is ready
  function initialize() {
    try {
      new AIContextGuard();
    } catch (error) {
      console.error('[AI Context Guard] Initialization error:', error);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }

})();
