// AI Context Guard - Background Service Worker v1.1.0
// Handles storage, messaging, and extension lifecycle

const AI_PLATFORMS = [
  'chatgpt.com',
  'chat.openai.com',
  'gemini.google.com',
  'bard.google.com',
  'copilot.microsoft.com',
  'claude.ai',
  'poe.com',
  'you.com',
  'perplexity.ai',
  'www.perplexity.ai',
  'huggingface.co',
  'chat.mistral.ai',
  'labs.google',
  'aistudio.google.com',
  'deepai.org',
  'writesonic.com',
  'jasper.ai',
  'copy.ai',
  'rytr.me',
  'cohere.com',
  'dashboard.cohere.com',
  'playground.openai.com',
  'platform.openai.com'
];

const DEFAULT_CONFIG = {
  enableWarnings: true,
  enableAutoRedact: true,
  enableLogging: true,
  scanDelay: 300
};

// Initialize extension on install
chrome.runtime.onInstalled.addListener((details) => {
  console.log('[AI Context Guard] Extension installed/updated:', details.reason);
  
  // Initialize storage with defaults
  chrome.storage.local.get(['acgConfig', 'acgEvents'], (result) => {
    if (!result.acgConfig) {
      chrome.storage.local.set({ acgConfig: DEFAULT_CONFIG });
    }
    if (!result.acgEvents) {
      chrome.storage.local.set({ acgEvents: [] });
    }
  });

  // Set up cleanup alarm
  chrome.alarms.create('cleanupOldEvents', { periodInMinutes: 1440 }); // Once per day
});

// Handle alarms
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'cleanupOldEvents') {
    cleanupOldEvents();
  }
});

// Clean up events older than 30 days
function cleanupOldEvents() {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  chrome.storage.local.get('acgEvents', (result) => {
    const events = result.acgEvents || [];
    const filteredEvents = events.filter(event => {
      const eventDate = new Date(event.timestamp);
      return eventDate > thirtyDaysAgo;
    });

    if (filteredEvents.length !== events.length) {
      chrome.storage.local.set({ acgEvents: filteredEvents });
      console.log('[AI Context Guard] Cleaned up', events.length - filteredEvents.length, 'old events');
    }
  });
}

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.type) {
    case 'GET_CONFIG':
      chrome.storage.local.get('acgConfig', (result) => {
        sendResponse(result.acgConfig || DEFAULT_CONFIG);
      });
      return true; // Keep channel open for async response

    case 'SET_CONFIG':
      chrome.storage.local.get('acgConfig', (result) => {
        const newConfig = { ...(result.acgConfig || DEFAULT_CONFIG), ...request.config };
        chrome.storage.local.set({ acgConfig: newConfig }, () => {
          broadcastConfigUpdate(newConfig);
          sendResponse({ success: true, config: newConfig });
        });
      });
      return true;

    case 'LOG_EVENT':
      logEvent(request.event, sender);
      sendResponse({ success: true });
      return true;

    case 'GET_EVENTS':
      chrome.storage.local.get('acgEvents', (result) => {
        sendResponse(result.acgEvents || []);
      });
      return true;

    case 'CLEAR_EVENTS':
      chrome.storage.local.set({ acgEvents: [] }, () => {
        sendResponse({ success: true });
      });
      return true;

    case 'GET_STATS':
      getStats().then(stats => sendResponse(stats));
      return true;

    default:
      sendResponse({ error: 'Unknown message type' });
      return false;
  }
});

// Log event from content script
function logEvent(event, sender) {
  chrome.storage.local.get('acgEvents', (result) => {
    const events = result.acgEvents || [];
    
    const enrichedEvent = {
      ...event,
      tabId: sender.tab?.id,
      tabTitle: sender.tab?.title,
      tabUrl: sender.tab?.url
    };

    events.push(enrichedEvent);

    // Keep only last 5000 events
    if (events.length > 5000) {
      events.splice(0, events.length - 5000);
    }

    chrome.storage.local.set({ acgEvents: events }, () => {
      updateBadge(events);
    });
  });
}

// Get statistics
async function getStats() {
  return new Promise((resolve) => {
    chrome.storage.local.get('acgEvents', (result) => {
      const events = result.acgEvents || [];
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const todayEvents = events.filter(e => {
        const eventDate = new Date(e.timestamp);
        eventDate.setHours(0, 0, 0, 0);
        return eventDate.getTime() === today.getTime();
      });

      const stats = {
        totalEvents: events.length,
        todayEvents: todayEvents.length,
        totalCritical: events.reduce((sum, e) => sum + (e.critical || 0), 0),
        todayCritical: todayEvents.reduce((sum, e) => sum + (e.critical || 0), 0),
        totalHigh: events.reduce((sum, e) => sum + (e.high || 0), 0),
        todayHigh: todayEvents.reduce((sum, e) => sum + (e.high || 0), 0),
        totalRedacted: events.filter(e => e.action === 'redacted').length,
        todayRedacted: todayEvents.filter(e => e.action === 'redacted').length,
        totalCancelled: events.filter(e => e.action === 'cancelled').length,
        totalForced: events.filter(e => e.action === 'forced').length
      };

      resolve(stats);
    });
  });
}

// Update extension badge
function updateBadge(events) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const todayBlocks = events.filter(e => {
    const eventDate = new Date(e.timestamp);
    eventDate.setHours(0, 0, 0, 0);
    return eventDate.getTime() === today.getTime() && e.action === 'redacted';
  }).length;

  if (todayBlocks > 0) {
    chrome.action.setBadgeText({ text: String(todayBlocks) });
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// Broadcast config update to all content scripts
function broadcastConfigUpdate(config) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.url && isAIPlatform(tab.url)) {
        chrome.tabs.sendMessage(tab.id, {
          type: 'CONFIG_UPDATE',
          config: config
        }).catch(() => {
          // Tab might not have content script loaded
        });
      }
    });
  });
}

// Check if URL is an AI platform
function isAIPlatform(url) {
  if (!url) return false;
  try {
    const hostname = new URL(url).hostname.replace(/^www\./, '');
    return AI_PLATFORMS.some(platform => hostname === platform || hostname.endsWith('.' + platform));
  } catch {
    return false;
  }
}

// Handle tab updates - ensure content script is injected
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && isAIPlatform(tab.url)) {
    // Content script should auto-inject via manifest, but verify
    chrome.tabs.sendMessage(tabId, { type: 'PING' }).catch(() => {
      // Content script not responding, try to inject
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content.js']
      }).catch(err => {
        // Might fail due to permissions, which is OK
        console.debug('[AI Context Guard] Could not inject content script:', err.message);
      });
    });
  }
});

// Keep service worker alive
chrome.runtime.onStartup.addListener(() => {
  console.log('[AI Context Guard] Extension started');
});

// Initialize badge on startup
chrome.storage.local.get('acgEvents', (result) => {
  updateBadge(result.acgEvents || []);
});

console.log('[AI Context Guard] Background service worker loaded');
